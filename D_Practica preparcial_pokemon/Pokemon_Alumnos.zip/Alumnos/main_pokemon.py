# MIT License
#
# Copyright (c) 2023 [UTN FRA](https://fra.utn.edu.ar/) All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# importar dentro de los parentesis las funciones necesarias
import re
from poke_lib_elemental import (
    limpiar_consola, imprimir_mensaje
)

# importar dentro de los parentesis las funciones necesarias
from poke_lib_basico import (

)
# importar dentro de los parentesis las funciones necesarias
from poke_lib_intermedio import (
    
)
# importar dentro de los parentesis las funciones necesarias
from poke_lib_int_avan import (

)
# importar dentro de los parentesis las funciones necesarias
from poke_lib_avanzado import (
    
)


def pokemon_app(path: str) -> None:
    
    while True:
        menu =\
        """
        1 - Imprimir nombre de pokemones.
        2 - Imprimir pokemones que tengan un ID par
        3 - Imprimir pokemones que tengan un ID multiplo de 25
        4 - Imprimir nombre de pokemones con su ID de prefijo.
        5 - Imprimir los pokemones con mas poder y cuanto poder tienen (misma fuerza)
        6 - Imprimir los pokemones con menos poder y cuanto poder tienen (misma fuerza)
        7 - Imprimir el promedio de poder de pokemones que entre sus tipos tenga 'psiquico'
        8 - Imprimir el promedio de poder de pokemones que entre sus tipos tenga 'fuego'
        9 - Imprimir el promedio de poder de pokemones que entre sus tipos tenga 'electrico'
        10 - Imprimir pokemones que posean mas de un tipo
        11 - Imprimir pokemones que posean mas de un tipo y su cantidad
        12 - Imprimir pokemones que posean mas de una evolucion
        13 - Imprimir pokemones que posean mas de una evolucion y su cantidad
        14 - Imprimir pokemones que posean mas de una fortaleza
        15 - Imprimir pokemones que posean mas de una fortaleza y su cantidad
        16 - Imprimir pokemones que posean mas de una debilidad
        17 - Imprimir pokemones que posean mas de una debilidad y su cantidad
        18 - Imprimir los tipos de cada pokemon
        19 - Imprimir las evoluciones de cada pokemon
        20 - Imprimir las debilidades de cada pokemon
        21 - Imprimir las fortalezas de cada pokemon
        22 - Imprimir pokemones agrupados por tipo. 
             (Si poseen mas de un tipo, debera aparecer en cada uno de ellos)
        23 - Imprimir pokemones con su id, nombre, fuerza, tipos, 
             evoluciones, fortalezas y debilidades
        24 - Filtrar pokemones por tipo y guardarlos en un JSON
        25 - Ordenar pokemones por una clave de forma ASC o DESC y guardar en JSON
        26 - Salir de la aplicacion.
        _______________________________________________________________
        """
        
        opcion = 0
        opcion_str = input(f'{menu}Su opcion: ')
        if re.match('^[0-9]{1,2}$', opcion_str):
            opcion = int(opcion_str)

        match opcion:
            case 1:
                pass
            case 2:
                pass
            case 3:
                pass
            case 4:
                pass
            case 5:
                pass
            case 6:
                pass
            case 7:
                pass
            case 8:
                pass
            case 9:
                pass
            case 10:
                pass
            case 11:
                pass
            case 12:
                pass
            case 13:
                pass
            case 14:
                pass
            case 15:
                pass
            case 16:
                pass
            case 17:
                pass
            case 18:
                pass
            case 19:
                pass
            case 20:
                pass
            case 21:
                pass
            case 22:
                pass
            case 23:
                pass
            case 24:
                pass
            case 25:
                pass
            case 26:
                break
            case _:
                imprimir_mensaje(f'La opcion {opcion} es incorrecta!', 'error')
        limpiar_consola()


if __name__ == '__main__':
    PATH = './data_pokemones.json' # Editar ruta de archivo JSON
    pokemon_app(PATH)